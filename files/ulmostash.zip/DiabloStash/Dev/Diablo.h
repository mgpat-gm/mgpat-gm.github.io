#ifndef _DIABLO_H_
#define _DIABLO_H_

#ifndef _DIABLO_C_
#define EX extern
#else /* _DIABLO_C_ */
#define EX
#endif /* _DIABLO_C_ */

#include "Struct.h"

enum { Gold = 0, Helm, Amulet, LRing, RRing, Weapon, Shield, Armor, Inventory, Belt, PointerItem, NumberOfItem, InventoryItemIndex, CharName, PropertyMax };

void     __fastcall (*GillianGeneralMenu)(void);
void     __fastcall (*AddMenuLine)(long int delta_x, long int line, long int centered, char *text, long int color, long int selectable);
  /* color : 00=white 01=Blue 02=red 03=gold */
void     __fastcall (*GillianGeneralSelect)(void);
void     __fastcall (*DisplayTownerMenu)(char index);
void     __fastcall (*Random)(long int unused, long int range);
void     __fastcall (*DisplayMenuFullLine)(long int line);
void     __fastcall (*SettMenuFullLine)(long int line);
void     __fastcall (*SetMenuLine98)(long int line, long int value);
void     __fastcall (*SetMenuLine04)(long int line, long int value);
void     __fastcall (*DisplayItemDescription)(ITEM *item, long int line, long int color);
void     __fastcall (*EraseMenuLinesRange)(unsigned long int first, unsigned long int last);
void     __fastcall (*PlayerDisplay4Items)(unsigned long int first);
void     __fastcall (*UpdateMenu)(void);
void     __fastcall (*UpdateLargeMenu)(void);
void     __fastcall (*UpdateSmallMenu)(void);
void     __fastcall (*DisplayMenuLine)(long int delta_x, long int line, long int centered, char *text, long int color, long int price);
void     __fastcall (*UpdateLift)(long int start, long int end);
void     __fastcall (*AdriaDisplay4Items)(unsigned long int first);
void     __fastcall (*GriswoldDisplay4Items)(unsigned long int first);
void     __fastcall (*GriswoldDisplay4PremiumItems)(unsigned long int first);
void     __fastcall (*PepinDisplay4Items)(unsigned long int first);
void     __fastcall (*SetCursorPicture)(long int index);
long int __fastcall (*DoesFitInInventory)(long int PlayerIndex, long int InvCaseIndex, long int ItemWidth, long int ItemHeight, long int CopyItem);
long int __fastcall (*DoesFitInInventoryOrBelt)(long int PlayerIndex, long int InvCaseIndex, long int ItemWidth, long int ItemHeight, long int CopyItem);
long int __fastcall (*CanSellItem)(long int index);
void     __fastcall (*RemoveGoldFromPlayer)(long int gold);
void     __fastcall (*AddCursorItemToInventory)(void);
void     __fastcall (*UpdateItem)(long int CurrentPlayer, long int ItemIndex);
void     __fastcall (*RemoveItemWithPosIndex)(long int PlayerIndex, long int ItemIndex);
void     __fastcall (*RemoveItemWithNegIndex)(long int PlayerIndex, long int ItemIndex);
void     __fastcall (*AdjustGoldPaquetSize)(long int PlayerIndex, long int ItemIndex);
/*void     __fastcall (*SetCursorSize)(long int index); */
long int __fastcall (*IsEquipable)(ITEM *Item);
long int __fastcall (*SaveFileRelated)(char *CharacterName);
void     __fastcall (*ReleaseFile)(char *param);
void     __fastcall (*PartOfLoadFileIII)(void);
void     __fastcall (*CreatePlayer)(long int PlrIndex, unsigned char PlrClass);

EX long int      *MenuCursorFrameIndex   ;
EX long int      *MenuLine               ;
EX char          *CurrentMenu            ;
EX char          *LargeMenu              ;
EX long int      *MenuWithLift           ;
EX long int      *CurrentPlayer          ;
EX long int      *FirstItemIndexInMenu   ;
EX long int      *NbLinesInMenu          ;
EX long int      *NbEntriesInLift        ;
EX long int      *PreviousMenuLine       ;
EX long int      *FirstLineOfMenu        ;
EX long int      *GillianBackHandler     ;
EX long int      *LastSelectableLine     ;
EX long int      *PreviousMenu           ;
EX long int      *PreviousFirstItemIndex ;
EX char          *ItemNumberOfLine       ;
EX long int      *CursorHeight           ;
EX long int      *CursorWidth            ;
EX long int      *TownerNameIndex        ; /* 0 Griswold, 1 Pepin, 3 Odgen, 4 Cain, 5 Farnham, 6 Adria, 7 Gillian, 8 Wirt */
EX long int      *FirstDialogIndex       ;
EX long int      *LastDialogIndex        ;
EX char          *MaxNumberOfPlayers     ;

EX char          *LoadFileHook1          ;
EX char          *LoadFileHook2          ;
EX char          *SaveFileHook           ;
EX char          *CreatePlrHook          ;

EX ITEM              *TmpPlayerItem          ; /* 0x30 */
EX MENULINESTRUCT    *MenuLineTbl            ; /* 0x19 */
EX SPELL             *SpellTbl               ;
EX ITEM              *GriswoldItems          ; /* 0x14 */
EX CHARACTER         **Characters            ;
EX CHARACTER         *CharactersAddress      ;

void InitDiablo(int version);

#endif /* _DIABLO_H_ */
