When modding Diablo/Hellfire, free space to add custom code become an serious issue very soon. I once inserted a new section (a second .text) of executable into it, but it was a hard task.
Another painful point is the ASM knowledge needed. C/C++ would be very easier to use.

What I propose is a way to write all the code you want in C/C++, put it into a DLL, and make the game load it. It comes with 3 parts :
*A loader
*A general purpose library called PlugUlmo.dll
*As many plug-in as wanted, for all the improvements you want


How to write a Plug-in :

You have to know how Diablo handles what you want to change.

There are 3 phases
*Fill the Diablo.c/.h interface so your C/C++ code can correctly use/access to Diablo's code.
*Write the C/C++ code.
*Insert access to your code (hooks) into Diablo executable.

I) Fill the Diablo.c/.h
=======================
Diablo.h contains the prototypes of the known functions, and the known variables.
You have to know a little how variables/result and passed to function.

Any function will return ESI/EDI/EBX/EBP unchanged. ECX and EDX are not supposed to keep their value after a function call.
The result is always returned into EAX.
The variables are passed into the stack, and sometime with the ECX/EDX parameters.
Most Diablo functions use __fastcall setting. This means that the first parameter (if exists) will go into ECX, the second (if exists) will go into EDX, the third and next will go to the stack.
Most standart functions (printf, etc...) don't use the __fastcall setting, and put all parameters to the stack.
Example :
void     __fastcall (*AddMenuLine)(long int delta_x, long int line, long int centered, char *text, long int color, long int selectable);
will be called like this :
PUSH selectable
PUSH color
PUSH text
PUSH centered
MOV EDX, line
MOV ECX, delta_x
CALL AddMenuLine

!! Caution !!
Variable names in Diablo.C/.h do contain the address of the in-game variable, not the variable itself. So if you want to know the MaxNumberOfPlayers (1 in SP, 4 in MP), read *MaxNumberOfPlayers and not MaxNumberOfPlayers.

II) Write code
==============
You should know how to do it ;)

III) Add hooks
==============
When your code is complete, you want to make Diablo access to it. Basically, you want to add some JMP and CALL to your functions, but you don't know where the dll will be loaded in memory, and BTW you don't to compute the jump offsets. PlugUlmo will do it for you.

You library must contains the two following functions :
int _Init(struct PLUGULMOFUNC PlugUlmoFunc);
void _Release(void);

The first one is called when the game loads, it will have to check that the version is correct and put the hooks.
_Release is use to free memory/save what wasn't/... It is not essential.
_Init must return 1 if the dll is correctly installed, else the dll will be unloaded.

First open memory access :
OldAccess = PlugUlmoFunc.SetMemoryAccess(".text", PAGE_EXECUTE_READWRITE);
".text" is the name of the memory section for code. If you want to alter data, use ".data" or ".rdata".
OldAccess = 0 means that an error occured.

Now insert hooks :
You have to write a JMP/CALL 00000000, then ask for a correct offset.
To write the JMP/CALL 00000000, use a patch :
PATCHTEXT (MyPatch[]) = {
   { H101 , "004710FC A150C86F00     E900000000" },
   { D109b, "0045BE98 A1288A6A00     E900000000" },
   { D109 , "0045BE98 A1288A6A00     E900000000" },
   { D107 , "0045BB12 5333DB5653     E900000000" },
   { NONE, "" }   /* Do not remove !! */
};
The 00000000 will be overwritten, but permit to check that the initial values are correct.
Then ask for a relative offset :
switch (version) {
   case D107 :
      PlugUlmoFunc.SetRelativeAddress(1 + 0x0045BB12, (unsigned long int)MyFunction);
      break;
   case D109 :
   case D109b:
      PlugUlmoFunc.SetRelativeAddress(1 + 0x0045BE98, (unsigned long int)MyFunction);
      break;
}

Finnally revert memory protection :
PlugUlmoFunc.SetMemoryAccess(".text", TextMemoryAccess);





Tutorial to come...