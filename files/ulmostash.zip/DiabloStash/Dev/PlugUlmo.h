#ifndef _PLUGULMO_H_
#define _PLUGULMO_H_

#ifndef NULL
#define NULL 0
#endif /* NULL */

#define BASEADDRESS 0x00400000
#define PAGE_EXECUTE_READWRITE	0x0040

typedef enum { PRED = 1, D100, D101, D102, D103, D104, D105, D106, D107, D108, D109, D109b, H100e, H100a, H101a, H101, CUSTOM, NONE } NUM_VERSION;

typedef struct {
   NUM_VERSION version;
   char *patch;
} PATCHTEXT;

struct PLUGULMOFUNC {
	NUM_VERSION version;
   FILE *log;
   unsigned long int (*SetMemoryAccess)(char *, unsigned long int);
   int (*SetRelativeAddress)(unsigned long int, unsigned long int);
   int (*SetAbsoluteAddress)(unsigned long int, unsigned long int);
   int (*ApplyPatchText)(PATCHTEXT []);
} PlugUlmoFunc;

#endif /* _PLUGU_H_ */
