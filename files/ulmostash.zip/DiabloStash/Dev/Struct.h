#ifndef _STRUCT_H_
#define _STRUCT_H_

typedef struct {
   long int     delta_x;
   long int     unknown04;  /* Zero or [16] = 6 */
   char         text[0x80];
   long int     centered;
   char         color;
   char         padding[3];
   long int     fullline;
   long int     selectable;
   long int     price;
} MENULINESTRUCT;

typedef struct {
   unsigned long int Seed;
   char              OriginLevel;
   char              OriginCode;
   short int         padding1;
   long int          EquipType;
   long int          XPos;
   long int          YPos;
   long int          Animated; /* Dlvl ? */
   long int          StartFrame;
   long int          EndFrame;
   long int          CurrFrame;
   long int          Fixed1; /* 0x60 */
   long int          Fixed2; /* 0x10 */
   long int          AnimationRelated1;
   long int          AnimationRelated2;
   long int          AnimationRelated3;
   long int          Identified;
   char              ItemType;               /* 00 Normal, 01 Magical, 02 Unique */
   char              ItemTypeName[0x40];
   char              ItemName[0x40];
   char              EquipPlace;
   char              EquipMainType;
   char              PAdding2;
   long int          Picture;                /* 0xB + Objcurs.cel index */
   long int          UnIdPrice;
   long int          IdPrice;
   long int          MinDam;
   long int          MaxDam;
   long int          AC;
   unsigned long int SpecialAbilityFlags;
   long int          MagicCode;
   long int          SpellCode;
   long int          CurrCharge;
   long int          MaxCharge;
   long int          CurrDur;
   long int          MaxDur;
   long int          EnhancedDamageBonus;
   long int          ToHitBonus;
   long int          ArmorBonus;
   long int          StrBonus;
   long int          MagicBonus;
   long int          DexterityBonus;
   long int          VitalityBonus;
   long int          FireResist;
   long int          LtngResist;
   long int          MagicResist;
   long int          ManaBonus;
   long int          HPBonus;
   long int          DamageBonus;
   long int          DamageModifier;
   long int          LightRadius;
   char              SpellLevelBonus;
   char              ManaCostBonus;
   short int         Padding3;
   char              SpellDurationBonus;
   long int          FireMinDmg;
   long int          FireMaxDmg;
   long int          LtngMinDmg;
   long int          LtngMaxDmg;
   long int          Bashing; /* Bashing        0,1,2,3 = none, penetrating, piercing, bashing */
   unsigned char     Prefix;
   unsigned char     Suffix;
   short int         Padding4;
   long int          PrefixPriceAdd;
   long int          PrefixPriceMult;
   long int          SuffixPriceAdd;
   long int          SuffixPriceMult;
   unsigned char     StrReq;
   unsigned char     MagReq;
   unsigned char     DexReq;
   char              Padding5;
   long int          Equipable;
   long int          BaseItemTypeIndex;
   long int          Unknown;
#ifdef _HELLFIRE_
   long int          Unknown2;
#endif /* _HELLFIRE_ */
} ITEM; /* size = 0x170 = 368 */

typedef struct {
   long int           action;
   char               Unknown0004[25];           /* all -1 */
   char               ValidPlayer;
   char               Padding001E[2];
   long int           Unknown0020[5];            /* action related/scroll related */
   long int           DungeonLevelOn;
   long int           PlayerPosX;
   long int           PlayerPosY;
   long int           Unknown0040[8];            /* various X/Y, maybe til in min... */
   long int           Unknown0060[4];            /* walk stuff  */
   long int           Unknown0070[2];
   long int           Appearence;                /* It's a summation of the following values (1 of each) Weapon: 02=Sword,04=Bow,05=Axe,06=Mace,08=Staff / Shield: 01=Shield / Armor:  10=Medium,20=Heavy */
   long int           Unknown007C[3];            /* animation related */
   long int           Unknown0088[3];            /* last frame number (9B4) / current frame number (1=new) / animation related (9B8) */
   long int           Unknown0094[2];
   long int           Unknown009C[2];            /* light related */
   long int           Unknown00A4[2];            /* action related/spell related (scrolls) */
   long int           CurrentSpell;
   long int           Unknown00B0;               /* action related */
   long int           SpellToCast;               /* -1 = no spell */
   long int           SpellOrigin;               /* cast from 0-skill 1-book 2-scroll 3-staff 4-staff (0 charges) */
   long int           Unknown00BC;
   char               Unknown00C0;               /* spell related */
   char               SpellLevel[0x25];          /* Index 0 for current spell */
   char               Unused[0x21];
   unsigned char      SpellAvaibleBook[8];       /* Bitfield, 36 entries */
   unsigned char      SpellAvaibleSkill[8];      /* Bitfield, 36 entries */
   unsigned char      SpellAvaibleScroll[8];     /* Bitfield, 36 entries */
   long int           Etheral;                   /* Immunity */
   long int           SpellShortcutIndex[4];     /* F5/F6/F7/F8 */
   char               SpellShortcutEnabled[4];   /* F5/F6/F7/F8, enabled = 01 */
   long int           HaveBow;
   char               CanBlock;                  /* Have Shield or Monk with Staff or no Weapon */
   char               SpellImmune;               /* Immunity, flash = 1, <>0 -> not hittable by any spell missiles */
   char               LightRadius;               /* 10 on start */
   char               Invisible;                 /* <>0 -> not selectable as monster-target */
   char               CharName[0x20];
   long int           CharacterClass;            /* 0,1,..,5=Warrior,Rogue,Mage,Monk,Bard,Barbarian */
   long int           StrengthCurrent;
   long int           StrengthBase;
   long int           MagicCurrent;
   long int           MagicBase;
   long int           DexterityCurrent;
   long int           DexterityBase;
   long int           VitalityCurrent;
   long int           VitalityBase;
   long int           CaracPoints;               /* bonus points to distribute */
   long int           BaseDamage;
   long int           BlockBonus;
   long int           LifeBase;
   long int           MaxLifeBase;
   long int           LifeCurrent;
   long int           MaxLifeCurrent;
   long int           LifeRatio;
   long int           ManaBase;
   long int           MaxManaBase;
   long int           ManaCurrent;
   long int           MaxManaCurrent;
   long int           ManaRatio;
   char               CharacterLevel;
   char               Unknown01B9[3];
   long int           Experience;
   long int           Unknown01C0;
   long int           NextLevelExpCap;
   char               Res;
   char               ResMagi;
   char               ResFire;
   char               ResLtng;
   long int           Gold;
   long int           Infravision;               /* 1 if on */
   long int           Unknown01D4[3];            /* First two may be coordinate cursor */
   long int           Unknown01E0;               /* slvl current spell */
   long int           Unknown01E4;
   long int           Unknown01E8[2];            /* frame related */
   long int           Unknown01F0;               /* spell cast frame related */
#ifdef _HELLFIRE_
   char               DLvlVisited[0x18];               /* dlvl visited */
   long int           Unknown0204[7];
#else /* _HELLFIRE_ */
   char               DLvlVisited[0x10];               /* dlvl visited */
   long int           Unknown0204[5];
#endif /* _HELLFIRE_ */
   long int           AnimationsLoaded;
   long int           Unknown021C;               /* animation related */
   long int           Unknown0220[0x57];         /* Animations related : anim speeds, number of frames, ... Jarulf seems to know more on it... */
   ITEM               ItemEquiped[7];            /* 0..6 =  Helm / Amulet / RingLeft / RingRight / Weapon / Shield / Armor */
   ITEM               ItemInventory[0x28];
   long int           NumberOfItems;
   char               ItemIndexInInventory[0x28];
   ITEM               ItemBelt[8];
   ITEM               ItemPointer[1];
   long int          WeaponMinDmg;
   long int          WeaponMaxDmg;
   long int          ACFromClass;                /* not Dex/5 */
   long int          EnhancedDamageBonus;
   long int          ToHitBonus;
   long int          ArmorBonus;
   long int          DamageBonus;
   long int          unknown5444;
   long int          unknown5448[2];             /* staff spell bitmap / Staff spells speedbook */
   unsigned long int SpecialAbilityFlags;        /* same as for items */
   long int          DamageModifier;
   char              SpellLevelBonus;
   char              ManaCostBonus;
   long int          SpellDurationBonus ;
   long int          Bashing;                    /* 0,1,2,3 = none, penetrating, piercing, bashing */
   long int          FireMinDmg;
   long int          FireMaxDmg;
   long int          LtngMinDmg;
   long int          LtngMaxDmg;
   long int          OilEffectOnCursor;
   char              DungeonType;                /* 0-3 */
   char              Counter[3];                 /* Counting what ?? */
   long int          Unknown547C;
   long int          ReflectCounter;
   long int          Unknown5484[3];
   long int          Dots;
   long int          Unknown5494;
   long int          SomeFlags;                  /* 01=Devastation,04=Peril,08=Jester,10h=Doppelganger */
   long int          Unknown549C[0x0F];
} CHARACTER; /* size = 0x54D8 = 21720 */

typedef struct {
     long int trigger;            /* Activation Trigger */
     char type;                   /* Item Type */
     char location;               /* Equipped Location */
     short int padding1;
     long int gfx;                /* Graphics Value */
     char code;                   /* Item Code */
     char unique;                 /* Unique item Code */
     short int padding2;
     long int name;               /* Pointer to Name */
     long int name2;              /* Pointer to Second Name */
     long int qlvl;               /* Quality Level */
     long int dur;                /* Durability */
     long int min_dmg;            /* Minimum Attack Damage */
     long int max_dmg;            /* Maximum Attack Damage */
     long int min_AC;             /* Minimum Armor Class */
     long int max_AC;             /* Maximum Armor Class */
     char str_req;                /* Required Strength to Use */
     char mag_req;                /* Required Magic to Use */
     char dex_req;                /* Required Dexterity to Use */
     char vit_req;                /* Required Vitality to Use */
     long int effect;             /* Special Effects */
     long int mag_code;           /* Magic Code */
     long int spell;              /* Spell Number */
     long int once;               /* Use Once Flag */
     long int price1;             /* Price #1 */
     long int price2;             /* Price #2 */
} ItemTbl; /* size = 0x4C = 76 */

typedef struct {
     long int name;               /* Pointer to Name */
     char type;                   /* Item Type */
     char qlvl;                   /* Quality Level */
     short int attribs;           /* Number of Attributes */
     long int price;              /* Gold Value */
     long int effect1;            /* Effect #1 */
     long int min1;               /* Minimum Value for Effect #1 */
     long int max1;               /* Maximum Value for Effect #1 */
     long int effect2;            /* Effect #2 */
     long int min2;               /* Minimum Value for Effect #2 */
     long int max2;               /* Maximum Value for Effect #2 */
     long int effect3;            /* Effect #3 */
     long int min3;               /* Minimum Value for Effect #3 */
     long int max3;               /* Maximum Value for Effect #3 */
     long int effect4;            /* Effect #4 */
     long int min4;               /* Minimum Value for Effect #4 */
     long int max4;               /* Maximum Value for Effect #4 */
     long int effect5;            /* Effect #5 */
     long int min5;               /* Minimum Value for Effect #5 */
     long int max5;               /* Maximum Value for Effect #5 */
     long int effect6;            /* Effect #6 */
     long int min6;               /* Minimum Value for Effect #6 */
     long int max6;               /* Maximum Value for Effect #6 */
} uniqueItemTbl; /* size = 0x54 = 84 */

typedef struct {
     long int name;               /* Pointer to Name */
     long int effects;            /* Effects */
     long int min_value;          /* Minimum Effect Value */
     long int max_value;          /* Maximum Effect Value */
     long int qlvl;               /* Quality Level */
     long int occur;              /* Occurance Probability */
     long int combo;              /* Combo Flag */
     long int cursed;             /* Cursed Flag */
     long int padding2;
     long int min_price;          /* Minimum Gold */
     long int max_price;          /* Maximum Gold */
     long int mult;               /* Multiplier */
} AffixTbl; /* size = 0x30 = 48 */

typedef struct {
     long int anim_size;          /* Animation Size */
     long int seed;               /* Seeding Size */
     long int anim;               /* Pointer to CL2 File */
     long int att2_trig;          /* Trigger Flag for Second Attack */
     long int sound;              /* Pointer to Sound */
     long int spec_sound;         /* Trigger Flag for Special Sounds */
     long int tran_trig;          /* Trigger Flag for Color Translation File */
     long int trn;                /* Pointer to Color Translation File */
     long int idle;               /* Idle Frameset */
     long int walk;               /* Walk Frameset */
     long int attack;             /* Attack Frameset */
     long int hit;                /* Hit Recovery Frameset */
     long int death;              /* Death Frameset */
     long int attack2;            /* Attack 2 Frameset */
     long int idle_spd;           /* Idle Playback Speed */
     long int walk_spd;           /* Walk Playback Speed */
     long int attack_spd;         /* Attack Playback Speed */
     long int hit_spd;            /* Hit Recovery Playback Speed */
     long int death_spd;          /* Death Playback Speed */
     long int attack2_spd;        /* Attack 2 Playback Speed */
     long int name;               /* Pointer to Monster's Name */
     char min_dlvl;               /* Minimum Dungeon Level */
     char max_dlvl;               /* Maximum Dungeon Level */
     short int mlvl;              /* Monster Level */
     long int min_hp;             /* Minimum Hit Points */
     long int max_hp;             /* Maximum Hit Points */
     long int attack_type;        /* Attack Type Value */
     long int IQ;                 /* Intelligence Factor */
     char sub;                    /* Subtype */
     char tohit1;                 /* To Hit Percentage of the Main Attack */
     char tohit1_frame;           /* To Hit Frame of the Main Attack */
     char min_dmg1;               /* Minimum Damage of the Second Attack */
     char max_dmg1;               /* Maximum Damage of the Second Attack */
     char tohit2;                 /* To Hit Percentage of the Second Attack */
     char tohit2_frame;           /* To Hit Frame of the Second Attack */
     char min_dmg2;               /* Minimum Damage of the Second Attack */
     char max_dmg2;               /* Maximum Damage of the Second Attack */
     char AC;                     /* Monster's Armor Class */
     short int type;              /* Monster Type */
     short int res1;              /* Resistance/Immunities for Normal/NM Difficulty */
     short int res2;              /* Resistance/Immunities for Hell Difficulty */
     short int drop;              /* Item Drop Specials */
     short int select;            /* Monster Selection Outline */
     long int XP;                 /* Experience Points */
} MonsterTbl;

typedef struct {
     long int type;               /* Monster Slot of the Unique */
     long int name;               /* Pointer to Name */
     long int trn;                /* Pointer to Color translation File */
     short int dlvl;              /* Dungeon Level */
     short int HP;                /* Hit Points */
     short int attack;            /* Attack Type */
     char min_dmg;                /* Minimum Attack Damage */
     char max_dmg;                /* Maximum Attack Damage */
     short int res;               /* Resistances/Immunities */
     short int pack;              /* Pack trigger */
     long int pack_spec;          /* Pack Special */
     long int sound;              /* Special Sound File */
} UniqueMonsterTbl;

typedef struct {
     char SP_dlvl;                /* Dungeon Level in SP */
     char MP_dlvl;                /* Dungeon Level in MP */
     char unknown1;
     char num;                    /* Quest Number */
     char unknown2;
     char spec;                   /* Special Level Setting */
     short int padding1;
     long int occurs;             /* MP Trigger Flag */
     long int unknown3;
} QuestTbl;

typedef struct {
     char num;                    /* Spell Number */
     char init_mana;              /* Initial Mana to Cast */
     short int anim;              /* Animation to Use While Casting */
     long int name1;              /* Pointer to Name as Spell */
     long int name2;              /* Pointer to Name as Skill */
     long int qlvl1;              /* Quality Level as Book */
     long int qlvl2;              /* Quality Level as Stave */
     long int scroll;             /* Scroll Type Used */
     long int town;               /* Active in Town */
     long int MagReq;            /* Magic Required at Slvl 1 or from Stave */
     char sound;                  /* Sound to use */
     char effect;                 /* Spell Effect */
     short int padding1;
     char dec;                    /* Mana Decrease per Slvl */
     char min;                    /* Minimum Mana Required to Cast */
     short int padding2;
     long int min_charge;         /* Minimum Number of Charges on Stave */
     long int max_charge;         /* Maximum Number of Charges on Stave */
     long int price;              /* Cost per Book */
     long int multi;              /* 5x Spell Multiplier */
} SPELL; /* size = 0x38 */

#endif /* _STRUCT_H_ */
