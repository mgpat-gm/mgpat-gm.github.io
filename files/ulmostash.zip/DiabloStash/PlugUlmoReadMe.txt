It comes with 3 parts :
*A loader
*A general purpose library called PlugUlmo.dll
*As many plug-in as wanted, for all the improvements you want

I) How to use it
================
It should be easy. Copy Loader.exe, PlugUlmo.dll and PlugUlmo.ini into diablo's directory (which should be c:\DIABLO). Add the plug-ins you want (Example : StashDiablo.dll and/or StashHellfire.dll). Double-click on Loader.

II) How to play without the CD
==============================
Copy DiabDat.MPQ from your CD into Diablo's Directory, and set :
Disable_CD_protection=YES
use_DIABDAT_from_HD=YES
into PlugUlmo.ini.

III) Launcher configuration
===========================
Section [Loader_Info] :
-----------------------

exe_file=
Is the name of the game executable. Usually Diablo.exe or Hellfire.exe, but you can put a Mod name here. Example :
exe_file=HLFDRK52.exe

dat_file=
To apply a .dat file (hack file). Useful with mods in .dat format.

log_file=
If you want some informations about what the loader/various DLL work. Debugging purpose (and useful for bug report).

Disable_CD_protection=
If YES, the game will not be forced to look on the CD for the DiabDat.MPQ file if he can find it elsewhere.

use_DIABDAT_from_HD=
Diablo uses 2 registry keys to handle paths :
HKEY_LOCAL_MACHINE\SOFTWARE\Blizzard Entertainment\Archives\DiabloInstall
HKEY_LOCAL_MACHINE\SOFTWARE\Blizzard Entertainment\Archives\DiabloCD
By default, the game looks for all files into the first path, but DiabDat.mpq into the second one.
Setting use_DIABDAT_from_HD=YES will make Diablo look for DiabDat.mpq into DiabloInstall registry key too.

Version=
PlugUlmo recognize what version of Diablo you are using, but if it fails (Mod) and you know what you are using, you can indicate it here.

Section [DLLToLoad] :
---------------------
Add here the names of the plug-in you want to load. Example :
StashDiablo=StashDiablo.dll
StashHellfire=StashHellfire.dll

IV) How does it work
====================
The loader puts the game exe into memory, may remove CD protection/apply a dat file, and adds a little routine which loads PlugUlmo.dll. Then it starts the game.

So PlugUlmo.dll is loaded, and it's main function gets executed. It look for all the dll to load, and for each one load it, and try to launch the routine _Init fo this dll.
If it can't find _Init, or if _Init return 0, the dll is unloaded.

TODO :
  * make the launcher load plug-in dll into diablo's space -> no more PlugUmo.dll