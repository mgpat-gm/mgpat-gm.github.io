Talk to Gillian, she should propose you to keep your items, and give them back to you.

There are 2 separated files for solo and multiplayer game. Exchanging the 2 is risky (items tend to morph).

It should work with mods, but in that case you are advised to change the filename of stash (in PlugUlmo.ini) to prevent mixing items from different mods.

Q : Why does Gillian keep items instead of a stash ?
Adding a towner is too much work at the moment.

Q : Why separated versions for Diablo and Hellfire ?
The Items structure has changed in Hellfire, and the Character struct and handling too. I had to made different compilation to handle different Items.

Q : What are the supported version ?
Diablo 1.07, 1.08, 1.09 and 1.09b. Support to other versions will be added in some future.
Hellfire european version 1.00, and 1.01.
Hellfire 1.00 american will be supported if someone send me the corresponding Hellfire.exe.